#!/bin/bash
# ═══════════════════════════════════════════════
#  ESTA — Деплой на сервер одной командой
#  Запуск: bash deploy.sh
# ═══════════════════════════════════════════════

set -e  # Останавливаемся при любой ошибке

DOMAIN="esta.md"  # ← Замените на ваш домен
EMAIL="info@esta.md"  # ← Ваш email для SSL

RED='\033[0;31m'
GREEN='\033[0;32m'
GOLD='\033[0;33m'
NC='\033[0m'

echo ""
echo -e "${GOLD}╔═══════════════════════════════════╗${NC}"
echo -e "${GOLD}║   ESTA · Deploy Script v1.0       ║${NC}"
echo -e "${GOLD}║   Молдова & Приднестровье          ║${NC}"
echo -e "${GOLD}╚═══════════════════════════════════╝${NC}"
echo ""

# ── 1. ПРОВЕРКА .env ──
if [ ! -f ".env" ]; then
  echo -e "${RED}✗ Файл .env не найден!${NC}"
  echo "  Скопируйте .env.example → .env и заполните токены"
  exit 1
fi

# Проверяем что токены заполнены
if grep -q "ВАШ_ТОКЕН\|your_telegram\|your_anthropic" .env; then
  echo -e "${RED}✗ В .env остались незаполненные значения!${NC}"
  echo "  Откройте .env и замените все placeholder'ы на реальные токены"
  exit 1
fi

echo -e "${GREEN}✓ .env проверен${NC}"

# ── 2. DOCKER ──
if ! command -v docker &> /dev/null; then
  echo "Устанавливаю Docker..."
  curl -fsSL https://get.docker.com | sh
  systemctl enable docker
  systemctl start docker
  echo -e "${GREEN}✓ Docker установлен${NC}"
else
  echo -e "${GREEN}✓ Docker уже установлен${NC}"
fi

if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
  echo "Устанавливаю Docker Compose..."
  apt-get install -y docker-compose-plugin 2>/dev/null || \
  curl -SL "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" \
    -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose
  echo -e "${GREEN}✓ Docker Compose установлен${NC}"
else
  echo -e "${GREEN}✓ Docker Compose уже установлен${NC}"
fi

# ── 3. SSL (Let's Encrypt) ──
if [ ! -d "/etc/letsencrypt/live/$DOMAIN" ]; then
  echo "Получаю SSL-сертификат для $DOMAIN..."
  apt-get install -y certbot 2>/dev/null || true
  
  # Временно поднимаем nginx на 80 для верификации
  docker run --rm -p 80:80 \
    -v /etc/letsencrypt:/etc/letsencrypt \
    certbot/certbot certonly \
    --standalone \
    --email $EMAIL \
    --agree-tos \
    --no-eff-email \
    -d $DOMAIN -d www.$DOMAIN

  echo -e "${GREEN}✓ SSL-сертификат получен${NC}"
else
  echo -e "${GREEN}✓ SSL уже настроен${NC}"
fi

# ── 4. СБОРКА И ЗАПУСК ──
echo ""
echo "Собираю контейнеры..."
docker compose build --no-cache

echo ""
echo "Запускаю ESTA..."
docker compose up -d

# ── 5. ПРОВЕРКА ──
sleep 5
echo ""
echo "Статус контейнеров:"
docker compose ps

# ── 6. АВТООБНОВЛЕНИЕ SSL ──
CRON_JOB="0 3 * * * docker run --rm -v /etc/letsencrypt:/etc/letsencrypt certbot/certbot renew --quiet && docker compose restart nginx"
(crontab -l 2>/dev/null | grep -v certbot; echo "$CRON_JOB") | crontab -
echo -e "${GREEN}✓ Автообновление SSL настроено${NC}"

# ── ИТОГ ──
echo ""
echo -e "${GOLD}═══════════════════════════════════════${NC}"
echo -e "${GREEN}  🚀 ESTA успешно запущен!${NC}"
echo -e "${GOLD}═══════════════════════════════════════${NC}"
echo ""
echo -e "  🌐 Лендинг:    ${GREEN}https://$DOMAIN${NC}"
echo -e "  🤖 Telegram:   ${GREEN}https://t.me/esta_realty_bot${NC}"
echo -e "  🗄 База:       ${GREEN}docker exec esta_bot python -c 'from parser import *; ...'${NC}"
echo ""
echo -e "  Логи бота:     ${GOLD}docker logs -f esta_bot${NC}"
echo -e "  Логи парсера:  ${GOLD}docker logs -f esta_parser${NC}"
echo -e "  Перезапуск:    ${GOLD}docker compose restart${NC}"
echo -e "  Остановка:     ${GOLD}docker compose down${NC}"
echo ""
